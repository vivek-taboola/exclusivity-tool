from flask import Flask, request, jsonify
import json
from flask_cors import CORS
import vertica_python
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException

app = Flask(__name__)
CORS(app)


def capture_full_page_screenshot(url, screenshot_path):
    try:
        # Set up Chrome options for headless mode
        chrome_options = Options()
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--disable-gpu')

        # Initialize Chrome driver
        driver = webdriver.Chrome(options=chrome_options)

        # Open the URL in the headless browser
        driver.get(url)

        # Wait for the page to fully load
        timeout = 10
        element_present = EC.presence_of_element_located((By.TAG_NAME, 'body'))
        WebDriverWait(driver, timeout).until(element_present)

        # Save the full-size screenshot to the specified path
        driver.save_screenshot(screenshot_path)

        # Close the browser
        driver.quit()

        return True
    except WebDriverException as e:
        print(f"Error capturing full-page screenshot: {e}")
        return False


def download_screenshot(url, pub_id):
    screenshot_path = f"screenshots/{pub_id}_full_screenshot.png"

    # Capture a screenshot and check if successful
    if capture_full_page_screenshot(url, screenshot_path):
        print(f"Screenshot captured and saved: {screenshot_path}")
        return True
    else:
        print("Error capturing screenshot")
        return False


@app.route('/extooldata', methods=['GET', 'POST'])
def extoolrun():
    data = request.get_json()
    newdata = json.dumps(data)
    pubid = json.loads(newdata)
    pub_id = pubid['input_data']
    return extoolmarge(pub_id)


def extoolmarge(pub_id):
    # Define your database connection details
    host = ''
    port = 5433
    database = ''
    username = ''
    password = ''
    try:
        # Create a connection
        connection = vertica_python.connect(host=host, port=port, user=username, password=password, database=database)
        # Create a cursor
        cursor = connection.cursor()
        # Define the SQL query
        sql_query = '''SELECT landing_page_url,SUM(views) AS total_views
        FROM reports.visit_value_report_daily
        WHERE publisher_id = %s AND DATE(data_timestamp) >= (CURRENT_DATE - 7)
        and landing_page_url is not null
        group by landing_page_url
        ORDER BY total_views DESC
        limit 10;''' % pub_id
        # Execute the query
        cursor.execute(sql_query)
        # Fetch all the results
        query_results = cursor.fetchall()
        if query_results == []:
            # Close out the cursor and then the connection to the database
            cursor.close()
            connection.close()
            # Return the JSON object with the results of the query
            output = {'extractedData': ["No taboola traffic found on the publisher in the last 7 Days"]}
            return jsonify(**output), 200
        else:
            # Display the results
            # print("Total number of rows in table: ", cursor.rowcount)
            urls_only = [query_results_new[0] for query_results_new in query_results]
            exclusivity_results = []
            for row in urls_only:
                landing_page_urls = row

                # Define keywords to search for in landing page source code
                Taboola_keywords = [
                    "window._taboola",
                    "cdn.taboola.com"
                ]
                Other_keywords = [
                    "widgets.outbrain.com",
                    "outbrain.js",
                    "outbrain",
                    "OUTBRAIN",
                    "MGID",
                    "mgid.com",
                    "jsc.mgid.com",
                    "trends.revcontent.com",
                    "revcontent.com",
                    "revcontent",
                    "Nativo"
                ]

                # Initialize list to store results
                # results = []
                screenshots_captured = False


                # if isinstance(landing_page_urls, str):
                #     if not landing_page_urls.startswith(('http://', 'https://')):
                #         landing_page_urls = 'https://' + url

                # Retrieve source code of landing page
                response = requests.get(landing_page_urls)
                if response.status_code == 200:
                    soup = BeautifulSoup(response.text, 'html.parser')
                    source_code = soup.prettify()

                    # Search for keywords in source cod

                    result1 = any(search_text_taboola in source_code for search_text_taboola in Taboola_keywords)
                    result2 = any(search_text_other in source_code for search_text_other in Other_keywords)

                    if result1 and result2:
                        exclusivity_breach = "Yes"
                    else:
                        # exclusivity_breach = jsonify([{"extractedData": {"URL": landing_page_urls, "exclusivity": "exclusivity_breach : No"}}])
                        exclusivity_breach = jsonify({"extractedData": [landing_page_urls, "exclusivity_breach : No"]})
                    try:
                        if exclusivity_breach == "Yes":
                            # Capture and download the screenshot
                            screenshots_captured = download_screenshot(landing_page_urls, pub_id)
                            exclusivity_results.append({"URL": landing_page_urls, "exclusivity_breach": "Yes"})
                        else:
                            exclusivity_results.append({"URL": landing_page_urls, "exclusivity_breach": "No"})
                    except Exception as e:
                        print(f"Error in downloading screenshot: {e}")

        # Check if any screenshots were captured
        if exclusivity_results:
            return jsonify({"extractedData": exclusivity_results})
        else:
            return jsonify({"extractedData": ["No exclusivity results"]})

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': 'Internal Server Error'}), 500


if __name__ == "__main__":
    app.run(debug=True)