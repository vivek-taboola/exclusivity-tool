import React, { useState } from "react";
import './Body.css'
import Backdrop from '@material-ui/core/Backdrop';
import CircularProgress from '@material-ui/core/CircularProgress';

function Body() {
  const [inputData, setInputData] = useState('');
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false); // Added loading state

  const sendDataToBackend = async () => {
    try {
      setLoading(true); // Set loading to true when making the request
      const response = await fetch('http://127.0.0.1:5000/extooldata', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ input_data: inputData }),
      });

      const result = await response.json();
      setData(result.extractedData); // Assuming the response has an 'extractedData' property
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false); // Set loading to false regardless of success or error
    }
  };

  return (
    <>
      <div className="show_body">
        <label>Publisher Id : </label>
        <input 
          type="number"
          className="pub_id"
          value={inputData} 
          onChange={(e) => setInputData(e.target.value)}
        />
        <button onClick={sendDataToBackend}>Check</button>
      </div>

      <Backdrop open={loading} style={{ zIndex: 1, color: '#fff' }}>
        <CircularProgress color="inherit" />
      </Backdrop>

      <div>
        {data.length > 0 ? (
          <table className="table">
            <thead>
              <tr>
                <th>URL</th>
                <th>Exclusivity Breach</th>
              </tr>
            </thead>
            <tbody>
              {data.map((item, index) => (
                <tr key={index}>
                  <td>{item.URL}</td>
                  <td>{item.exclusivity_breach}</td>
                </tr>
              ))}
            </tbody>
          </table> 
        ) : (
          <p></p>
        )}
      </div>
    </>
  );
}

export default Body;